#include "ArrayList.h"
#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>

int cargarPersonas(ArrayList* listaUsuarios, char* path)
{
    FILE* f;
    eCliente* perAux;
    int cant;
    int retorno = -1;
    char id [10];
    char nombre[50];
    char sexo [10];
    char numeroTelefono [21];
    char importe [10];


    f = fopen(path, "r");
    if(f == NULL)
    {
        printf("No se pudo abrir el archivo\n");
        exit(1);
    }

    while(!feof(f))
    {

        perAux = (eCliente*)malloc(sizeof(eCliente));
        if(perAux!=NULL)
        {

            if(feof(f))
            {
                break;

            }
            cant=fscanf(f, "%[^,],%[^,],%[^,],%[^,],%[^\n] \n", id, nombre, sexo, numeroTelefono, importe);

            if(cant == 5)
            {

                perAux->id=atoi(id);
                strcpy(perAux->nombre,nombre);

                strcpy(perAux->sexo,sexo);
                printf("1 llego");
                strcpy(perAux->numeroTelefono,numeroTelefono);
                perAux->importe=atoi(importe);

                listaUsuarios->add(listaUsuarios, perAux);
                retorno =0;

            }
            else
            {
                printf("error al leer con fscanf\n");
            }
        }
        else
        {
            printf("No se pudo leer el ultimo registro\n");
            break;
        }

    }
    fclose(f);
    return retorno;

}


void mostrarUsuario(eCliente* num)
{
    printf("%-20d%20s\t%3s\t%3s\t%3d\n",num->id, num->nombre, num->sexo, num->numeroTelefono, num->importe );
}

void mostrarTodos(ArrayList* cliente)
{
    int i;
    eCliente* unUsuario=newUsuario();
    unUsuario= cliente->get(cliente,1);
    printf("ID     Nombre           Sexo     Numero           Importe\n\n");
    for(i=0; i<cliente->len(cliente); i++)
    {
        if(i== 33 || i == 66 || i == 99 || i == 132 || i == 165 || i== 198 || i == 231 || i == 264 || i == 297 || i== 330 || i == 363 || i == 396 || i == 429 || i == 462)
        {
            getchar();
        }
        unUsuario= cliente->get(cliente,i);
        mostrarUsuario(unUsuario);
    }
}
eCliente* newUsuario()
{
    eCliente* retorno=NULL;
    eCliente* nuevoUsuario=(eCliente*)malloc(sizeof(eCliente));
    if(nuevoUsuario!=NULL)
    {
        strcpy(nuevoUsuario->nombre,"");
        strcpy(nuevoUsuario->numeroTelefono,"");
        strcpy(nuevoUsuario->sexo,"");
        nuevoUsuario->importe=0;
        nuevoUsuario->id=0;
        retorno = nuevoUsuario;
    }
    else
    {
        printf("Error no se consiguio memoria");
        exit(1);
    }
    return retorno;
}
