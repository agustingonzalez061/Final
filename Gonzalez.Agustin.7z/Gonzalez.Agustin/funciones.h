#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#include "ArrayList.h"
#define PERSONAL = 0
#define FAMILIAR = 1
#define CORPORATIVO = 2
typedef struct
{
    int id;
    char nombre[51];
    char sexo[2];
    char numeroTelefono[21];
    int importe;
}eCliente;
typedef struct
{
    int id;
    int tipo;
    int idCliente;
    int importeFinal;
}eAbono;

int cargarPersonas(ArrayList* listaUsuarios, char* path);
void mostrarTodos(ArrayList* cliente);
void mostrarUsuario(eCliente* num);
eCliente* newUsuario();
#endif // FUNCIONES_H_INCLUDED
