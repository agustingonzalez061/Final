#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"




int menuModifica();
int cargarPersonas(ArrayList* , char* );
int ordenar(void* usuarioA,void* usuarioB);
ArrayList* depurar(ArrayList* depurados);
int generarArchivo(char* fileName,ArrayList* lista);
